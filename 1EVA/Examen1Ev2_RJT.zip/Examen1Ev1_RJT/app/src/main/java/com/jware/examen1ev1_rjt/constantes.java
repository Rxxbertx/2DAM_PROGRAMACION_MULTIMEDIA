package com.jware.examen1ev1_rjt;

public class constantes {

    public static String DOLARES = "dólares";
    public static String EUROS = "euros";
    public static String BITCOIN = "bitcoins";


}
