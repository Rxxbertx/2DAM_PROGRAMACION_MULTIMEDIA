package com.roberto.minigame.interfaces;

public interface Nivel {

    void comprobarEstado();
    void comprobarFinal();


void cargarContenido();


}
